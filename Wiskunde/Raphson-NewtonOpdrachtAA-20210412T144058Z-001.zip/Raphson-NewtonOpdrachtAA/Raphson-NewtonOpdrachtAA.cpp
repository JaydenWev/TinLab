// Raphson-NewtonOpdrachtAA.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <math.h>
using namespace std;

int j;

double f(double x)
{
    return exp(x) - pow(x, 2) + 3 * x - 2;
}

double fd(double x)
{
    return exp(x) - 2 * x + 3;
}

void lesDrie(double x)
{
    std::cout << "x_0: " << x << endl;
    for (int i = 1; i < 30; i++) {
        j = i;
        x = x - (f(x) / fd(x));
        std::cout << "x_" << j << ": " << x << endl;
    }
    return;
}

void lesVierA(double a, double b, double magn)
{
    double m = (a + b) / 2;
    cout    << "iteratie: 0" << endl
            << "a: " << a << endl
            << "b: " << b << endl
            << "m: " << m << endl
            << "f(m): " << f(m) << endl << endl;
    for(int i=1; abs(f(m)) >= pow(10.0, magn);i++)
    {
        if((f(m) < 0))
        {
            a = m;
        }
        else
        {
            b = m;
        }
        m = (a + b) / 2;
        cout    << "iteratie: " << i << endl  
                << "a: " << a << endl
                << "b: " << b << endl
                << "m: " << m << endl
                << "f(m): " << f(m) << endl << endl;
    }
    return;

}
void lesVierB(float b, float a, float n) 
{
    float h = (b - a) / n;
    float benadering = 0;

    for (float x = a; b >= x ; x = x + h) 
    {
        benadering = (exp(x) / x) + benadering;
    }
    benadering = h * benadering;
    cout << "benadering integraal: " << b << ";" << a << " = " << benadering << endl;

    return;
}

int main()
{
    //lesDrie(12);
    //lesVierA(0, 1, -3);
    //lesVierB(5, 1, 1);
    //lesVierB(5, 1, 4);
    lesVierB(5, 1, 10000);
}




// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
